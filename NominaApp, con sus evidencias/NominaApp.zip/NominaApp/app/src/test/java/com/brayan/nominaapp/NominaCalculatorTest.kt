package com.brayan.nominaapp

import org.junit.Assert.assertEquals
import org.junit.Test

class NominaCalculatorTest {

    @Test
    fun testCasoA_SalarioMinimoConHorasExtra() {
        val resultado = calcularNomina(
            salarioBasico = 1_750_905.0,
            horasDiurnas = 10.0,
            horasNocturnas = 4.0,
            esDominical = false,
            transporteEmpresa = false
        )

        assertEquals(8338.0, resultado.valorHora, 1.0)
        assertEquals(162584.0, resultado.totalHorasExtra, 1.0)
        assertEquals(249095.0, resultado.auxilioTransporte, 1.0)
        assertEquals(2162584.0, resultado.totalDevengado, 1.0)
        assertEquals(76540.0, resultado.aporteSalud, 1.0)
        assertEquals(76540.0, resultado.aportePension, 1.0)
        assertEquals(0.0, resultado.fondoSolidaridad, 1.0)
        assertEquals(2009505.0, resultado.salarioNeto, 1.0)
        assertEquals(RangoSalarial.RANGO_1, resultado.rango)
    }

    @Test
    fun testCasoB_HorasExtraDominicales() {
        val resultado = calcularNomina(
            salarioBasico = 2_500_000.0,
            horasDiurnas = 6.0,
            horasNocturnas = 2.0,
            esDominical = true,
            transporteEmpresa = false
        )

        assertEquals(11905.0, resultado.valorHora, 1.0)
        assertEquals(216667.0, resultado.totalHorasExtra, 1.0)
        assertEquals(249095.0, resultado.auxilioTransporte, 1.0)
        assertEquals(2965762.0, resultado.totalDevengado, 1.0)
        assertEquals(108667.0, resultado.aporteSalud, 1.0)
        assertEquals(108667.0, resultado.aportePension, 1.0)
        assertEquals(0.0, resultado.fondoSolidaridad, 1.0)
        assertEquals(2748428.0, resultado.salarioNeto, 1.0)
        assertEquals(RangoSalarial.RANGO_1, resultado.rango)
    }

    @Test
    fun testCasoC_TransporteEmpresa() {
        val resultado = calcularNomina(
            salarioBasico = 3_000_000.0,
            horasDiurnas = 5.0,
            horasNocturnas = 0.0,
            esDominical = false,
            transporteEmpresa = true
        )

        assertEquals(14286.0, resultado.valorHora, 1.0)
        assertEquals(89286.0, resultado.totalHorasExtra, 1.0)
        assertEquals(0.0, resultado.auxilioTransporte, 1.0)
        assertEquals(3089286.0, resultado.totalDevengado, 1.0)
        assertEquals(123571.0, resultado.aporteSalud, 1.0)
        assertEquals(123571.0, resultado.aportePension, 1.0)
        assertEquals(0.0, resultado.fondoSolidaridad, 1.0)
        assertEquals(2842143.0, resultado.salarioNeto, 1.0)
        assertEquals(RangoSalarial.RANGO_1, resultado.rango)
    }

    @Test
    fun testCasoD_SalarioAltoConFondoSolidaridad() {
        val resultado = calcularNomina(
            salarioBasico = 8_000_000.0,
            horasDiurnas = 0.0,
            horasNocturnas = 0.0,
            esDominical = false,
            transporteEmpresa = false
        )

        assertEquals(38095.0, resultado.valorHora, 1.0)
        assertEquals(0.0, resultado.totalHorasExtra, 1.0)
        assertEquals(0.0, resultado.auxilioTransporte, 1.0)
        assertEquals(8000000.0, resultado.totalDevengado, 1.0)
        assertEquals(320000.0, resultado.aporteSalud, 1.0)
        assertEquals(320000.0, resultado.aportePension, 1.0)
        assertEquals(80000.0, resultado.fondoSolidaridad, 1.0)
        assertEquals(7280000.0, resultado.salarioNeto, 1.0)
        assertEquals(RangoSalarial.RANGO_3, resultado.rango)
    }

    @Test
    fun testClasificacionRangos() {
        assertEquals(RangoSalarial.RANGO_1, clasificarRango(1_750_905.0))
        assertEquals(RangoSalarial.RANGO_1, clasificarRango(3_000_000.0))
        assertEquals(RangoSalarial.RANGO_2, clasificarRango(4_000_000.0))
        assertEquals(RangoSalarial.RANGO_3, clasificarRango(8_000_000.0))
    }
}
